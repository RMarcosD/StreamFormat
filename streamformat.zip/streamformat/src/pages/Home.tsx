import React from "react";
import { Typewriter } from "react-simple-typewriter";
import NavBar from "../components/HorizontalNavBar/HorizontalNavBar";
import Footer from "../components/Footer/Footer";
import "../styles/Home.css";

const Home: React.FC = () => {
  return (
    <div className="page-container">
      <NavBar />
      <div className="home-container">
        <h2>Bienvenido a StreamFormat</h2>
        <p className="typewriter-text">
          <Typewriter
            words={[
              "Este es un sistema diseñado para facilitar el manejo y formato de tus datos.",
            ]}
            loop={5}
            typeSpeed={50}
            deleteSpeed={30}
            delaySpeed={2000}
          />
        </p>
      </div>
      <Footer />
    </div>
  );
};

export default Home;
