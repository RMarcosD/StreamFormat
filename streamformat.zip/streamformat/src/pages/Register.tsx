import React, { useState } from "react";
import InputField from "../components/InputField/InputField";
import Footer from "../components/Footer/Footer";
import "../styles/Register.css";

const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    name: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [fieldsEnabled, setFieldsEnabled] = useState({
    lastName: false,
    email: false,
    password: false,
    confirmPassword: false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleContinue = (field: keyof typeof fieldsEnabled) => {
    setFieldsEnabled({ ...fieldsEnabled, [field]: true });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert("Las contraseñas no coinciden");
      return;
    }
    console.log("Usuario Registrado:", formData);
  };

  return (
    <div className="register-container">
      <h1>Registrarse</h1>
      <form onSubmit={handleSubmit} className="register-box">
        {/** Nombre */}
        <div className="input-group">
          <label htmlFor="name">
            Ingrese su Nombre<span className="required">*</span>
          </label>
          <InputField
            type="text"
            name="name"
            placeholder="Nombre"
            value={formData.name}
            onChange={handleChange}
          />
          <button
            type="button"
            className="continue-btn"
            disabled={formData.name.trim() === ""}
            onClick={() => handleContinue("lastName")}
          >
            Continuar
          </button>
        </div>

        {/** Apellido */}
        <div className="input-group">
          <label htmlFor="lastName">
            Ingrese su Apellido<span className="required">*</span>
          </label>
          <InputField
            type="text"
            name="lastName"
            placeholder="Apellido"
            value={formData.lastName}
            onChange={handleChange}
            disabled={!fieldsEnabled.lastName}
          />
          <button
            type="button"
            className="continue-btn"
            disabled={
              !fieldsEnabled.lastName || formData.lastName.trim() === ""
            }
            onClick={() => handleContinue("email")}
          >
            Continuar
          </button>
        </div>

        {/** Correo */}
        <div className="input-group">
          <label htmlFor="email">
            Ingrese su Correo Corporativo<span className="required">*</span>
          </label>
          <InputField
            type="email"
            name="email"
            placeholder="Correo Corporativo"
            value={formData.email}
            onChange={handleChange}
            disabled={!fieldsEnabled.email}
          />
          <button
            type="button"
            className="continue-btn"
            disabled={!fieldsEnabled.email || formData.email.trim() === ""}
            onClick={() => handleContinue("password")}
          >
            Continuar
          </button>
        </div>

        {/** Contraseña */}
        <div className="input-group">
          <label htmlFor="password">
            Ingrese una Contraseña<span className="required">*</span>
          </label>
          <InputField
            type="password"
            name="password"
            placeholder="Contraseña"
            value={formData.password}
            onChange={handleChange}
            disabled={!fieldsEnabled.password}
          />
          <button
            type="button"
            className="continue-btn"
            disabled={
              !fieldsEnabled.password || formData.password.trim() === ""
            }
            onClick={() => handleContinue("confirmPassword")}
          >
            Continuar
          </button>
        </div>

        {/** Confirmar Contraseña */}
        <div className="input-group">
          <label htmlFor="confirmPassword">
            Confirmar su Contraseña<span className="required">*</span>
          </label>
          <InputField
            type="password"
            name="confirmPassword"
            placeholder="Confirmar Contraseña"
            value={formData.confirmPassword}
            onChange={handleChange}
            disabled={!fieldsEnabled.confirmPassword}
          />
          <button
            type="submit"
            className="continue-btn"
            disabled={
              !fieldsEnabled.confirmPassword ||
              formData.confirmPassword.trim() === ""
            }
          >
            Registrar
          </button>
        </div>
      </form>
      <Footer />
    </div>
  );
};

export default Register;
