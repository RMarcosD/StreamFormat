import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import InputField from "../components/InputField/InputField";
import Footer from "../components/Footer/Footer";
import HorizontalNavBar from "../components/HorizontalNavBar/HorizontalNavBar"; // Asegúrate de ajustar la ruta correctamente
import { Link } from "react-router-dom";
import "../styles/Login.css";

const Login: React.FC = () => {
  const { login } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password);
  };

  return (
    <div className="page-container">
      {/* Navbar fijo en la parte superior */}
      <HorizontalNavBar />
      <div className="login-container">
        <div className="login-box">
          <h1>Iniciar Sesión</h1>
          <form onSubmit={handleSubmit}>
            <label htmlFor="email">Ingrese su Correo Corporativo</label>
            <InputField
              type="email"
              placeholder="Correo Corporativo"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <label htmlFor="password">Ingrese su Contraseña</label>
            <InputField
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit" className="submit-btn">
              Iniciar Sesión
            </button>
          </form>
          <p className="register-text">
            Si aún no tienes una cuenta,{" "}
            <Link to="/Register">
              <span className="register-btn">Regístrate</span>
            </Link>
          </p>
        </div>
      </div>
      {/* Footer fijo al final de la página */}
      <Footer />
    </div>
  );
};

export default Login;
