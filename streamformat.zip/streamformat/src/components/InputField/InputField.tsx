import React from 'react';
import './InputField.css';

interface InputFieldProps {
  type: string;
  placeholder: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name?: string;
  disabled?: boolean; // Nuevo prop para manejar el estado de habilitación
}

const InputField: React.FC<InputFieldProps> = ({ type, placeholder, value, onChange, name, disabled }) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      name={name}
      className="input-field"
      required
      disabled={disabled} // Aplicar el estado de habilitación
    />
  );
};

export default InputField;
