import React from "react";
import logo from "../../assets/logo_sanms_transparente.png"; // Ruta al logo desde el componente Logo.tsx

const Logo: React.FC = () => {
  return (
    <img
      src={logo}
      alt="StreamFormat Logo"
      style={{
        height: "70px", // Ajusta según sea necesario
        width: "auto",
        marginLeft: "50px",
      }}
    />
  );
};

export default Logo;
