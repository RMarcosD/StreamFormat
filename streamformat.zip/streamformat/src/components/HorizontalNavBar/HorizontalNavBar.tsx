import React from "react";
import Logo from "../Logo/Logo"; // Ruta al componente Logo.tsx
import "./HorizontalNavbar.css";

const HorizontalNavBar: React.FC = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Logo />
        <h1>StreamFormat</h1>
        {/* Enlaces de Login y Register */}
        <div className="navbar-links">
          <a className="navbar-link button" href="/login">
            Iniciar Sesión
          </a>
          <a className="navbar-link button" href="/register">
            Registrarse
          </a>
        </div>
      </div>
    </nav>
  );
};

export default HorizontalNavBar;
