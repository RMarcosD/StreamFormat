import React, { createContext, useState, ReactNode } from "react";

interface AuthContextProps {
  isAuthenticated: boolean;
  login: (email: string, password: string) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextProps>({
  isAuthenticated: false,
  login: () => {},
  logout: () => {},
});

export const AuthProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const login = (email: string, password: string) => {
    // Agregar lógica para autenticar al usuario
    if (password === "mysecurepassword") {
      // Si la contraseña es correcta
      console.log("Logged in:", email);
      setIsAuthenticated(true);
    } else {
      // Si la contraseña es incorrecta
      console.log("Incorrect password for:", email);
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    console.log("Logged out");
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
